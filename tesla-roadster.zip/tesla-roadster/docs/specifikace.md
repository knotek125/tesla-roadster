# Základní specifikace Tesla Roadster

- 0–100 km/h: 0,81 sekundy
- Maximální rychlost: přes 370 km/h
- Dojezd: přes 300 mil (cca 480+ km)
- Trysky: cold-gas thrusters od SpaceX
- Verze: Performance, Thrust, Rocket
- Výroba: plánována na rok 2028
