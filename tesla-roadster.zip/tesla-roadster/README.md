# Tesla Roadster 2028

Vítejte v mém repozitáři o **Tesla Roadsteru** – nejnovějším elektrickém supersportu, který umí i létat!

## Design a vzhled

![Tesla Roadster](images/roadster.png)

Nový Roadster má futuristický design inspirovaný Cybertruckem a SpaceX.

## Hlavní přednosti

- **Nejrychlejší zrychlení** na světě (0,81 s)
- Schopnost krátkých letů a přemetů díky tryskám
- Sací systém pro jízdu vzhůru nohama
- Tři verze: Performance, Thrust a Rocket

## Jak funguje létání

![Thrusters](images/thrusters.png)

Roadster používá **cold-gas thrusters** (trysky na stlačený vzduch) vyvinuté ve spolupráci se SpaceX. Dokáže krátké skoky, přemety a dokonce jízdu vzhůru nohama díky sacímu systému.

## Užitečné odkazy

- [Oficiální stránka Tesla](https://www.tesla.com)
- [SpaceX](https://www.spacex.com)
- [Elon Musk na X](https://x.com/elonmusk)

## Zrychlení

![Acceleration](images/acceleration.png)

Roadster zvládne **0–100 km/h za pouhých 0,81 sekundy** díky kombinaci elektromotorů a trysek.

---

> **Shrnutí:** Tento repozitář je cvičení práce s Gitem zaměřené na Tesla Roadster. Obsahuje složkovou strukturu, 3 obrázky, externí odkazy a přesně 15 commitů.
